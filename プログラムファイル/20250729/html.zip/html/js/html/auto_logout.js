// 即座に実行される無名関数（IIFE: Immediately Invoked Function Expression）
// グローバルスコープを汚染せず、変数の名前衝突を防ぐ
(function() {
    // ログアウト処理を行うPHPファイルのURL
    var logoutUrl = 'https://hosplist.kawasaki-m.ac.jp/login/logout.php';
    
    // 自動ログアウトまでの時間設定（ 1時間
    var timeout = 60 * 60 * 1000; // 1時間（ミリ秒）

    // カウントダウン表示を開始する秒数（ログアウトの60秒前から表示）
    var countdownStart = 60; // １分前からカウントダウン

    // タイマーとカウントダウンタイマーの変数
    var timer, countdownTimer;
    
    // カウントダウン表示用のDOM要素
    var countdownTab = null;

    // カウントダウンタブを画面から削除する関数
    function removeCountdownTab() {
        // カウントダウンタブが存在し、かつ親要素が存在する場合
        if (countdownTab && countdownTab.parentNode) {
            // 親要素からカウントダウンタブを削除
            countdownTab.parentNode.removeChild(countdownTab);
            // 変数をnullにリセット
            countdownTab = null;
        }
    }

    // カウントダウンタブを表示する関数
    function showCountdownTab(seconds) {
        // カウントダウンタブがまだ作成されていない場合
        if (!countdownTab) {
            // 新しいdiv要素を作成
            countdownTab = document.createElement('div');
            // IDを設定（CSS等でスタイリングするため）
            countdownTab.id = 'auto-logout-countdown-tab';
            // body要素に追加して画面に表示
            document.body.appendChild(countdownTab);
        }
        // カウントダウンの残り秒数を表示
        countdownTab.textContent = 'あと' + seconds + '秒でログアウトされます';
    }

    // カウントダウンを開始する関数
    function startCountdown() {
        // 残り秒数を初期化
        var remain = countdownStart;
        // 初回のカウントダウン表示
        showCountdownTab(remain);
        
        // 1秒ごとにカウントダウンを更新するタイマーを設定
        countdownTimer = setInterval(function() {
            remain--; // 残り秒数を減らす
            if (remain > 0) {
                // まだ残り時間がある場合は表示を更新
                showCountdownTab(remain);
                console.log('カウントダウン: ' + remain + '秒');
            } else {
                // カウントダウン終了時の処理
                removeCountdownTab(); // カウントダウン表示を削除
                clearInterval(countdownTimer); // タイマーを停止
            }
        }, 1000); // 1秒（1000ミリ秒）間隔で実行
    }

    // タイマーをリセットして新たに開始する関数
    // ユーザーの操作（マウス移動、キー入力等）が検出された際に呼び出される
    function resetTimer() {
        // 既存のタイマーをクリアして重複実行を防ぐ
        clearTimeout(timer);
        clearInterval(countdownTimer);
        removeCountdownTab(); // カウントダウン表示があれば削除
        
        // 新しいタイマーを設定
        timer = setTimeout(function() {
            // カウントダウン開始（ログアウトの20秒前）
            startCountdown();
            
            // カウントダウン終了後、実際にログアウト処理を実行
            timer = setTimeout(function() {
                window.location.href = logoutUrl; // ログアウトページにリダイレクト
            }, countdownStart * 1000); // カウントダウン期間（20秒）後に実行
        }, timeout - countdownStart * 1000); // メインタイムアウト時間からカウントダウン期間を引いた時間後に実行
    }

    // ユーザーのアクティビティを監視するイベントリスナーを設定
    // 以下のイベントが発生した際にタイマーをリセット
    ['mousemove', 'mousedown', 'keydown', 'touchstart', 'wheel'].forEach(function(evt) {
        // 各イベントタイプに対してイベントリスナーを追加
        // 第3引数のtrueはキャプチャフェーズでイベントを捕捉することを意味する
        document.addEventListener(evt, resetTimer, true);
    });

    // 初期化：ページ読み込み時にタイマーを開始
    resetTimer();
})();