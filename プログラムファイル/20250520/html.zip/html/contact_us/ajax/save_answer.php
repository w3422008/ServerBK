<?php
// 管理者用
// 依頼内容の登録・変更を行う
session_start();

$user_id = $_SESSION['member']['user_id'];
$user_name = $_SESSION['member']['user_name'];

require_once('../../functions.php');

// データベース接続
$dbh = get_db_connect();

if(isset($_POST['history'])){
    // 既に依頼されていた内容を変更する場合
    $que_id = $_POST['que_id'];
    $order = html_escape($_POST['order']);

    reply_change_message($que_id,$order,$dbh);


}else{
    // 新たに依頼する内容を登録する場合
    $que_id = $_POST['que_id'];
    $answer = html_escape($_POST['answer']);
    $advisability = $_POST['advisability'];
    $supp_status = $_POST['supp_status'];
    $db_adv=111;
    if(mb_strlen($_POST['db_adv'])!==0){
        $db_adv=$_POST['db_adv'];
    }
    
    update_rep_message($user_id,$user_name,$que_id,$answer,$advisability,$supp_status,$db_adv,$dbh);

}
?>