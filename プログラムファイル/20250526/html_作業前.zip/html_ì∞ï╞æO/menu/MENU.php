<!DOCTYPE html>
<html>
<head><link rel="shortcut icon" href="../favicon.ico">
    <title>MENU | 医療機関情報システム</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<!--CSS/JS-->
<!-- *全画面必須 ---------->
  <!--UIkit3-->
  <link rel="stylesheet" href="../css/uikit.min.css" />
  <script src="../js/uikit.min.js"></script>
  <script src="../js/uikit-icons.min.js"></script>

  <!--style.css-->
  <link rel="stylesheet" href="../css/style.css"/>
  <link rel="stylesheet" href="../css/buttons.css" /><!--※-->
  <link rel="stylesheet" href="../css/marker.css"/><!--:*marker CSS-->

  <!--font awesome-->
  <link rel="stylesheet" href="../css/all.min.css" />
<!--------------------* -->
</head>
<body>
  <!-- **header -->
  <header uk-sticky>
    <?php include_once("../header.php"); ?>
    <!-- パンくず -->
      <ul class="uk-breadcrumb breadcrumb">
          <li><span>MENU</span></li>
      </ul>
  </header>


  <!-- **main -->
    <!--*main_body-->
    <div class="uk-margin-large-top uk-margin-large-bottom uk-container uk-container-center uk-widrh-1-2@m uk-width-1-2@l uk-width-1-3@xl">
            <div class="uk-margin">
            <form action="../search/checkbox_control.php">
            <button type="submit" class="button_1 uk-button-large uk-circle uk-width-1-1" name='search'><span>医療機関検索</span></button>
            </form>
            </div>

        <?php
      //櫻間
      if($user_adm === '1'){
        //櫻間
      ?>

        <fieldset class="uk-fieldset uk-margin" id="search-area">
<!--
          <legend class="uk-legend">メンテナンス</legend>
            <div class="uk-margin-bottom uk-margin-small-top">
            <div><span uk-icon="triangle-down"></span> <span>選択したデータのメンテナンス画面に移動します</span></div>
              <select class="uk-select" name="MT" id="" style="width:65%">
                <option value="maindata">
                　医療機関データ
                </option>
                <option value="introduction">
                　紹介・逆紹介データ
                </option>
                <option value="support">
                　院外診療支援・院外研修データ
                </option>
                <option value="receivable">
                　受入可能な診療内容データ
                </option>
              </select>

              <button class="button_2 uk-button" style="width:30%">
                <span class="uk-visible@s">取込み </span><span uk-icon="arrow-right"></span>
              </button>
            </div>
-->

      <!--　高橋セレクトボックスの値に応じて「取込み」ボタンのリンク先を変える
            <div class="uk-margin">
            <form action="../maintenance/maindata_MT.php">
              <button type="submit" class="button_2 uk-button uk-circle uk-width-1-1"><span>医療機関データ取込み</span></button>
            </form>
            </div>

            <div class="uk-margin">
            <form action="../maintenance/introduction_MT.php">
              <button type="submit"class="button_2 uk-button uk-circle uk-width-1-1"><span>紹介・逆紹介データ取込み</span></button>
            </form>
            </div>

            <div class="uk-margin">
            <form action="../maintenance/support_MT.php">
              <button type="submit" class="button_2 uk-button uk-circle uk-width-1-1"><span>院外診療支援・院外研修データ取込み</span></button>
            </form>
            </div>

            <div class="uk-margin">
              <form action="../maintenance/receivable_MT.php">
              <button type="submit" class="button_2 uk-button uk-circle uk-width-1-1"><span>受入可能な診療内容データ取り込み</span></button>
              </form>
            </div>
      -->

          <div class="uk-margin-medium-top uk-child-width-1-1@m" uk-grid>
              <!--櫻間20221117-->
            <div>
            <form action="../hos_management/manage_control.php">
            <!--form action="../delete/hide_hos_control.php"-->
            <button class="button_3 uk-button uk-width-1-1"><span class="fas fa-hospital"></span> <span>医療機関 管理</span></button>
            
            </form>
            </div>
                <!--櫻間20221117-->
            <div>
            <form action="../user/user_MT_control.php">
            <button type="submit" class="button_3 uk-button uk-width-1-1"><span uk-icon="users"></span> <span>ユーザー管理</span></button>
            </form>
            </div>
             <!--櫻間20230801-->
            <div>
            <form action="../all_csv/all_control.php">
            <button class="button_3 uk-button uk-width-1-1"><span class="fas fa-hospital"></span> <span>全件出力</span></button>
            </form>
            </div>
            <!--櫻間20230801-->
          
            <!--三宅-->
            <div>
            <form action="../message/login.php">
            <button type="submit" class="button_3 uk-button uk-width-1-1"><span class="fas fa-envelope"></span> <span>メッセージ管理</span></button>
            </form>
            </div>

          <!-- <div>
            <form action="../import/data_select.php">
            <button type="submit" class="button_3 uk-button uk-width-1-1"><span class="fas fa-file-import"></span> <span>インポート機能</span></button>
            </form>
            </div>
          </div> -->
          
          <!--
          <div class="uk-margin uk-child-width-1-2@m" uk-grid>
            <div>
            <form action="../user/user_MT_control.php">
            <button type="submit" class="button_3 uk-button uk-width-1-1"><span uk-icon="history"></span> <span>ログ</span></button>
            </form>
            </div>

            <div>
            <form action="../user/user_MT_control.php">
            <button type="submit" class="button_3 uk-button uk-width-1-1"><span uk-icon="history"></span> <span>ログ</span></button>
            </form>
            </div>
          </div>
      -->


          </fieldset>

      <?php 
      }
      ?>
      </div>

    </div>
</body>
</html>




